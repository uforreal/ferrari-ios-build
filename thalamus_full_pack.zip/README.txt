
HOW TO RUN YOUR PERSONAL THALAMUS
=================================

1. Install Python (if not installed).
   Download from: https://www.python.org/downloads/

2. Open the folder containing these files.

3. Double-click "thalamus_engine.py" 
   (OR run `python thalamus_engine.py` in terminal).

4. START TEACHING
   - Type "Open door" -> System will ask "What is this?"
   - Select "1" (Command)
   - Type "door" (Keyword)
   
   - Next time you say "door", it will happen instantly.
   
FILES IN THIS PACK:
- thalamus_engine.py  : The Thinking Engine
- thalamus_memory.json : The Memory File (It grows as you use it)
