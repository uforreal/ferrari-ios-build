import time
import json
import os

# ==========================================
# 1. THE STORAGE (The "Store Inventory")
# ==========================================
MEMORY_FILE = "thalamus_memory.json"

class Memory:
    def __init__(self):
        self.patterns = {}  # { "keyword": "DESTINATION" }
        self.load()

    def load(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, 'r') as f:
                    self.patterns = json.load(f)
            except:
                self.patterns = {}
    
    def save(self):
        with open(MEMORY_FILE, 'w') as f:
            json.dump(self.patterns, f, indent=2)

    def learn(self, trigger_word, destination):
        # The Store stocks the item
        self.patterns[trigger_word.lower()] = destination
        self.save()

    def recall(self, text):
        # Check if we have this in stock
        # Naive matching: checks if any known keyword is in the input
        text = text.lower()
        for keyword, destination in self.patterns.items():
            if keyword in text:
                return destination, keyword # Return dest and what triggered it
        return None, None


# ==========================================
# 2. THE STANDARD (Signal Packet)
# ==========================================
class UniversalInputObject:
    def __init__(self, raw_data):
        self.payload = {"raw": raw_data}
        self.metadata = {}
        self.routing = {"destination": None, "reason": None}


# ==========================================
# 3. THE THALAMUS (The Adaptive Router)
# ==========================================
class Thalamus:
    def __init__(self):
        self.memory = Memory()

    def route(self, uio: UniversalInputObject):
        raw = uio.payload["raw"]
        
        # STEP 1: CHECK MEMORY (The Store Shelf)
        # --------------------------------------
        cached_dest, keyword = self.memory.recall(raw)
        if cached_dest:
            uio.routing["destination"] = cached_dest
            uio.routing["reason"] = f"Learned Pattern Match ('{keyword}')"
            return uio, False # False = No Training Needed

        # STEP 2: FALLBACK TO FACTORY (Simulated AI)
        # --------------------------------------
        # If we don't know it, we assume it needs the Big Brain
        uio.routing["destination"] = "L.L.M._CORE"
        uio.routing["reason"] = "Unknown Pattern - Sent to Factory"
        return uio, True # True = Needs Training/Feedback


# ==========================================
# 4. LIVE LEARNING LOOP
# ==========================================
def interactive_shop():
    print("\n" + "="*60)
    print("   THALAMUS STORE: SELF-LEARNING MODE")
    print("   1. Dictionary starts empty.")
    print("   2. If I don't know something, I send it to AI.")
    print("   3. YOU teach me what it was, and I remember next time.")
    print("   Type 'exit' to quit.")
    print("="*60 + "\n")

    thalamus = Thalamus()

    while True:
        try:
            print("\n" + "-"*60)
            user_input = input(">> USER SAYS: ")
            if user_input.strip().lower() in ["exit", "quit"]:
                break
            
            # Create Packet
            signal = UniversalInputObject(user_input)
            
            # Thalamus Routing
            routed_signal, needs_training = thalamus.route(signal)
            
            # Show Result
            dest = routed_signal.routing['destination']
            print(f"   [ROUTER]   --> {dest} ({routed_signal.routing['reason']})")
            
            # --- THE LEARNING MOMENT ---
            if needs_training:
                # In a real system, the AI might auto-tag this. 
                # Here, YOU are the 'Teacher' finalizing the transaction.
                print("   [SYSTEM]   I had to ask the Factory (AI). What should I have done?")
                print("              1. This was a COMMAND (Device)")
                print("              2. This was a FACT SEARCH (Web)")
                print("              3. Keep it as AI (It's complex)")
                
                choice = input("   >> TEACH ME (1/2/3): ")
                
                if choice == "1":
                    # Extract a keyword? For simplicity, we use the whole phrase or first word
                    # Let's ask user for the trigger word to remember
                    keyword = input("   >> What keyword triggers this? (e.g. 'lights'): ")
                    thalamus.memory.learn(keyword, "DEVICE_CONTROLLER")
                    print(f"   [STORE]    Stocked! '{keyword}' -> DEVICE_CONTROLLER")
                    
                elif choice == "2":
                    keyword = input("   >> What keyword triggers this? (e.g. 'weather'): ")
                    thalamus.memory.learn(keyword, "SEARCH_API")
                    print(f"   [STORE]    Stocked! '{keyword}' -> SEARCH_API")
                    
                else:
                    print("   [STORE]    Left as AI task.")
            
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    interactive_shop()
