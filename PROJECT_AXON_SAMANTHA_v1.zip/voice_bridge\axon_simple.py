"""
AXON SIMPLE: One-File Voice Bridge
===================================
No threading, no async complexity. Just works.
"""

import time
import ctypes
from ctypes import wintypes
import psutil
import asyncio
import websockets
import json

# ==========================================
# WINDOWS API
# ==========================================
user32 = ctypes.windll.user32

def get_focus():
    """Get current focused window info."""
    hwnd = user32.GetForegroundWindow()
    
    # Get title
    length = user32.GetWindowTextLengthW(hwnd) + 1
    buffer = ctypes.create_unicode_buffer(length)
    user32.GetWindowTextW(hwnd, buffer, length)
    title = buffer.value
    
    # Get process name
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        process = psutil.Process(pid.value).name()
    except:
        process = "unknown"
    
    return process, title

# ==========================================
# SPEECH GENERATOR (Simple Templates)
# ==========================================
APP_SPEECH = {
    "arc.exe": "Research mode active.",
    "chrome.exe": "Doing some research?",
    "msedge.exe": "Browsing something?",
    "antigravity.exe": "Back to coding.",
    "cmd.exe": "Terminal ready.",
    "powershell.exe": "PowerShell active.",
    "explorer.exe": "File explorer opened.",
    "code.exe": "VS Code ready.",
}

def get_speech(process_name):
    """Get what the AI should say for this app."""
    lower = process_name.lower()
    
    for app, speech in APP_SPEECH.items():
        if app in lower:
            return speech
    
    # Unknown app
    clean_name = process_name.replace(".exe", "")
    return f"Opening {clean_name}."

# ==========================================
# MAIN SYSTEM
# ==========================================
class SimpleAXON:
    def __init__(self):
        self.clients = set()
        self.last_process = ""
        self.running = True
    
    async def handle_client(self, websocket):
        """Handle a connected client."""
        print(f"[AXON] ✓ Client connected: {websocket.remote_address}")
        self.clients.add(websocket)
        
        try:
            # Keep connection alive
            async for msg in websocket:
                pass
        except:
            pass
        finally:
            self.clients.discard(websocket)
            print(f"[AXON] ✗ Client disconnected")
    
    async def broadcast(self, text):
        """Send message to all clients."""
        if not self.clients:
            print(f"[AXON] No clients connected")
            return
        
        message = json.dumps({"type": "speak", "text": text})
        
        for client in list(self.clients):
            try:
                await client.send(message)
                print(f"[AXON] → Sent: {text}")
            except:
                self.clients.discard(client)
    
    async def perception_loop(self):
        """Watch for focus changes."""
        print("[AXON] Starting perception loop...")
        
        while self.running:
            try:
                process, title = get_focus()
                
                # Focus changed?
                if process != self.last_process and process != "":
                    print(f"\n[FOCUS] {self.last_process} → {process}")
                    
                    # Generate speech
                    speech = get_speech(process)
                    print(f"[SPEECH] {speech}")
                    
                    # Broadcast to clients
                    await self.broadcast(speech)
                    
                    self.last_process = process
                
                await asyncio.sleep(0.1)  # 100ms
                
            except Exception as e:
                print(f"[ERROR] {e}")
                await asyncio.sleep(1)
    
    async def run(self):
        """Start everything."""
        print("""
╔═══════════════════════════════════════════════════════════╗
║   AXON SIMPLE: Voice Bridge (No-Frills Edition)          ║
╚═══════════════════════════════════════════════════════════╝
        """)
        
        # Start WebSocket server
        server = await websockets.serve(self.handle_client, "0.0.0.0", 8765)
        print(f"[AXON] Server listening on ws://0.0.0.0:8765")
        print(f"[AXON] Waiting for pc_bridge.py to connect...\n")
        
        # Run perception loop
        await self.perception_loop()

# ==========================================
# ENTRY POINT
# ==========================================
if __name__ == "__main__":
    system = SimpleAXON()
    try:
        asyncio.run(system.run())
    except KeyboardInterrupt:
        print("\n[AXON] Shutting down...")
