import 'package:flutter_tts/flutter_tts.dart';

/// TTS Service: Speaks messages with British accent
class TTSService {
  final FlutterTts _tts = FlutterTts();
  bool _isInitialized = false;

  bool get isInitialized => _isInitialized;

  Future<void> initialize() async {
    try {
      // Configure TTS for British English (Gemini-like voice)
      await _tts.setLanguage('en-GB');  // British English
      await _tts.setSpeechRate(0.5);    // Slightly slower = more pleasant
      await _tts.setVolume(0.9);
      await _tts.setPitch(1.0);

      // Try to set specific voice (iOS)
      var voices = await _tts.getVoices;
      if (voices != null) {
        // Look for Daniel (British male) or Kate (British female)
        for (var voice in voices) {
          final voiceName = voice['name'] as String?;
          if (voiceName != null && 
              (voiceName.contains('Daniel') || voiceName.contains('Kate'))) {
            await _tts.setVoice({'name': voiceName, 'locale': 'en-GB'});
            print('[TTS] Using voice: $voiceName');
            break;
          }
        }
      }

      _isInitialized = true;
      print('[TTS] ✓ Initialized with British English');
    } catch (e) {
      print('[TTS] ⚠ Init failed: $e');
    }
  }

  Future<void> speak(String text) async {
    if (!_isInitialized) {
      print('[TTS] ⚠ Not initialized, attempting init...');
      await initialize();
    }

    try {
      await _tts.speak(text);
      print('[TTS] 🔊 Speaking: $text');
    } catch (e) {
      print('[TTS] ⚠ Speak error: $e');
    }
  }

  Future<void> stop() async {
    await _tts.stop();
  }

  void dispose() {
    _tts.stop();
  }
}
