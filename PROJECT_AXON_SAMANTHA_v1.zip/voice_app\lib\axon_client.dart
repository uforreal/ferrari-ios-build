import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

/// AXON Client: Receives pushes from PC via RAMEN protocol
class AXONClient {
  final String serverUrl;
  final Function(Map<String, dynamic>) onMessage;
  final Function() onConnected;
  final Function() onDisconnected;

  WebSocketChannel? _channel;
  Timer? _reconnectTimer;
  bool _isConnecting = false;

  AXONClient({
    required this.serverUrl,
    required this.onMessage,
    required this.onConnected,
    required this.onDisconnected,
  });

  Future<void> connect() async {
    if (_isConnecting) return;
    _isConnecting = true;

    try {
      print('[AXON Client] Connecting to $serverUrl...');
      
      _channel = WebSocketChannel.connect(Uri.parse(serverUrl));
      
      // Listen for messages
      _channel!.stream.listen(
        (message) {
          try {
            final data = jsonDecode(message as String) as Map<String, dynamic>;
            print('[AXON Client] ← Received: ${data['type']}');
            onMessage(data);
          } catch (e) {
            print('[AXON Client] ⚠ JSON decode error: $e');
          }
        },
        onDone: () {
          print('[AXON Client] ✗ Disconnected');
          onDisconnected();
          _scheduleReconnect();
        },
        onError: (error) {
          print('[AXON Client] ⚠ Error: $error');
          onDisconnected();
          _scheduleReconnect();
        },
      );

      onConnected();
      print('[AXON Client] ✓ Connected');
    } catch (e) {
      print('[AXON Client] ⚠ Connection failed: $e');
      onDisconnected();
      _scheduleReconnect();
    } finally {
      _isConnecting = false;
    }
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 3), () {
      print('[AXON Client] Attempting reconnect...');
      connect();
    });
  }

  void disconnect() {
    _reconnectTimer?.cancel();
    _channel?.sink.close();
  }

  void sendPing() {
    try {
      _channel?.sink.add(jsonEncode({'type': 'ping'}));
    } catch (e) {
      print('[AXON Client] ⚠ Ping failed: $e');
    }
  }
}
