"""
OPTIC NERVE v4.1: Surgical Efficiency Update
=============================================
Fixes from v4.0:
- ClipboardScribe now only fires on Ctrl+C (no ghost events)
- Fullscreen gate skips peripheral scanning
- 80% occlusion threshold for peripheral visibility
- Tiered loop architecture (100ms/300ms/3s)
- Idle detection with slowdown
- Low-power mode for fullscreen apps
- Batched clipboard output
"""

import time
import json
import ctypes
from ctypes import wintypes
from collections import defaultdict
import psutil

# ==========================================
# 1. WINDOWS API HOOKS (The "Eyeball")
# ==========================================
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

# Define WNDENUMPROC type globally for EnumWindows
WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, ctypes.py_object)

# Explicitly define argument types for key user32 functions
user32.EnumWindows.argtypes = [WNDENUMPROC, ctypes.py_object]
user32.GetForegroundWindow.restype = wintypes.HWND
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.IsIconic.argtypes = [wintypes.HWND]

# Monitor info structure
class MONITORINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", wintypes.RECT),
        ("rcWork", wintypes.RECT),
        ("dwFlags", wintypes.DWORD)
    ]

user32.GetMonitorInfoW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MONITORINFO)]
user32.GetMonitorInfoW.restype = wintypes.BOOL


def get_active_window_info():
    """Get foreground window info."""
    hwnd = user32.GetForegroundWindow()
    length = user32.GetWindowTextLengthW(hwnd) + 1
    buffer = ctypes.create_unicode_buffer(length)
    user32.GetWindowTextW(hwnd, buffer, length)
    window_title = buffer.value
    
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    
    rect = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(rect))
    
    # Get process name
    try:
        process = psutil.Process(pid.value)
        process_name = process.name()
    except:
        process_name = "unknown"
    
    return {
        "window_handle": hwnd,
        "window_title": window_title,
        "process_id": pid.value,
        "process_name": process_name,
        "position": {
            "left": rect.left, "top": rect.top,
            "right": rect.right, "bottom": rect.bottom,
            "width": rect.right - rect.left, "height": rect.bottom - rect.top
        }
    }

def get_cursor_position():
    point = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(point))
    return {"x": point.x, "y": point.y}


# ==========================================
# 2. FULLSCREEN + OCCLUSION ENGINE (v4.1)
# ==========================================

class WindowMap:
    """
    Smart Desktop Scanner with fullscreen gate and 80% occlusion.
    """
    
    OCCLUSION_THRESHOLD = 0.80  # 80% covered = hidden
    
    def __init__(self):
        self.windows = {}
        self.last_focused_hwnd = None
    
    def _get_window_rect(self, hwnd):
        """Get window rectangle tuple."""
        rect = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rect))
        return (rect.left, rect.top, rect.right, rect.bottom)
    
    def _get_monitor_work_area(self, hwnd):
        """Get the work area of the monitor containing this window."""
        monitor = user32.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
        info = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        user32.GetMonitorInfoW(monitor, ctypes.byref(info))
        wa = info.rcWork
        return (wa.left, wa.top, wa.right, wa.bottom), monitor
    
    def _is_fullscreen(self, hwnd):
        """Check if window covers entire monitor work area."""
        win_rect = self._get_window_rect(hwnd)
        work_area, _ = self._get_monitor_work_area(hwnd)
        
        # Allow small tolerance (taskbar might shift things by a few pixels)
        tolerance = 10
        return (
            win_rect[0] <= work_area[0] + tolerance and
            win_rect[1] <= work_area[1] + tolerance and
            win_rect[2] >= work_area[2] - tolerance and
            win_rect[3] >= work_area[3] - tolerance
        )
    
    def _calculate_occlusion(self, target_rect, blocking_rect):
        """Calculate what percentage of target is covered by blocking rect."""
        t_left, t_top, t_right, t_bottom = target_rect
        b_left, b_top, b_right, b_bottom = blocking_rect
        
        # Calculate intersection
        inter_left = max(t_left, b_left)
        inter_top = max(t_top, b_top)
        inter_right = min(t_right, b_right)
        inter_bottom = min(t_bottom, b_bottom)
        
        # No intersection
        if inter_left >= inter_right or inter_top >= inter_bottom:
            return 0.0
        
        inter_area = (inter_right - inter_left) * (inter_bottom - inter_top)
        target_area = (t_right - t_left) * (t_bottom - t_top)
        
        if target_area <= 0:
            return 0.0
        
        return inter_area / target_area
    
    def _is_mostly_hidden(self, target_rect, focused_rect):
        """Check if target is >= 80% covered by focused window."""
        return self._calculate_occlusion(target_rect, focused_rect) >= self.OCCLUSION_THRESHOLD
    
    def _enum_windows_callback(self, hwnd, results):
        """Callback for EnumWindows."""
        if user32.IsWindowVisible(hwnd):
            length = user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buffer = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buffer, length + 1)
                title = buffer.value
                
                rect = self._get_window_rect(hwnd)
                _, monitor = self._get_monitor_work_area(hwnd)
                
                results.append({
                    "hwnd": hwnd,
                    "title": title,
                    "rect": rect,
                    "monitor": monitor
                })
        return True
    
    def scan(self, force_full=False):
        """
        Smart scan with fullscreen gate.
        Returns focused + peripheral windows.
        """
        foreground_hwnd = user32.GetForegroundWindow()
        
        # Get focused window info
        length = user32.GetWindowTextLengthW(foreground_hwnd) + 1
        buffer = ctypes.create_unicode_buffer(length)
        user32.GetWindowTextW(foreground_hwnd, buffer, length)
        focused_title = buffer.value
        
        focused_rect = self._get_window_rect(foreground_hwnd)
        _, focused_monitor = self._get_monitor_work_area(foreground_hwnd)
        
        # FULLSCREEN GATE: If fullscreen, skip peripheral scan
        if self._is_fullscreen(foreground_hwnd) and not force_full:
            return {
                "focused": {"title": focused_title, "fullscreen": True},
                "peripheral": [],
                "hidden": [],
                "is_fullscreen": True
            }
        
        # PERIPHERAL SCAN: Only windows on same monitor, not mostly hidden
        results = []
        user32.EnumWindows(WNDENUMPROC(self._enum_windows_callback), results)
        
        peripheral = []
        hidden = []
        
        for win_data in results:
            hwnd = win_data["hwnd"]
            title = win_data["title"]
            rect = win_data["rect"]
            monitor = win_data["monitor"]
            
            # Skip the focused window itself
            if hwnd == foreground_hwnd:
                continue
            
            # Skip tiny windows
            width = rect[2] - rect[0]
            height = rect[3] - rect[1]
            if width < 50 or height < 50:
                continue
            
            # Skip windows on different monitors
            if monitor != focused_monitor:
                continue
            
            # Skip minimized windows
            if user32.IsIconic(hwnd):
                hidden.append({"title": title, "state": "MINIMIZED"})
                continue
            
            # Check 80% occlusion against focused window
            if self._is_mostly_hidden(rect, focused_rect):
                hidden.append({"title": title, "state": "HIDDEN"})
            else:
                peripheral.append({"title": title, "state": "VISIBLE"})
        
        return {
            "focused": {"title": focused_title, "fullscreen": False},
            "peripheral": peripheral[:5],  # Limit to 5
            "hidden": hidden[:3],
            "is_fullscreen": False
        }


# ==========================================
# 3. CLIPBOARD SCRIBE (Fixed - Ctrl+C gated)
# ==========================================

CF_TEXT = 1
CF_UNICODETEXT = 13
CF_HDROP = 15
CF_DIB = 8

class ClipboardScribe:
    """
    Clipboard tracker that ONLY fires on user-initiated copy (Ctrl+C).
    No more ghost events.
    """
    
    def __init__(self):
        self.last_sequence = ctypes.windll.user32.GetClipboardSequenceNumber()
        self.pending_events = []  # For batching
        self.last_flush = time.time()
    
    def _get_clipboard_formats(self):
        """Check what formats are available on clipboard."""
        formats = []
        try:
            ctypes.windll.user32.OpenClipboard(0)
            
            if ctypes.windll.user32.IsClipboardFormatAvailable(CF_HDROP):
                formats.append("FILES")
            if ctypes.windll.user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
                formats.append("TEXT")
            if ctypes.windll.user32.IsClipboardFormatAvailable(CF_DIB):
                formats.append("IMAGE")
                
            ctypes.windll.user32.CloseClipboard()
        except:
            pass
        return formats
    
    def _get_file_count(self):
        """If clipboard has files, get the count."""
        try:
            ctypes.windll.user32.OpenClipboard(0)
            h_drop = ctypes.windll.user32.GetClipboardData(CF_HDROP)
            if h_drop:
                count = ctypes.windll.shell32.DragQueryFileW(h_drop, 0xFFFFFFFF, None, 0)
                ctypes.windll.user32.CloseClipboard()
                return count
            ctypes.windll.user32.CloseClipboard()
        except:
            pass
        return 0
    
    def _get_text_preview(self, max_chars=30):
        """Get a short preview of copied text."""
        try:
            ctypes.windll.user32.OpenClipboard(0)
            h_data = ctypes.windll.user32.GetClipboardData(CF_UNICODETEXT)
            if h_data:
                kernel32.GlobalLock.restype = ctypes.c_wchar_p
                text = kernel32.GlobalLock(h_data)
                preview = text[:max_chars] if text else ""
                kernel32.GlobalUnlock(h_data)
                ctypes.windll.user32.CloseClipboard()
                return preview.replace("\n", " ").replace("\r", "")
            ctypes.windll.user32.CloseClipboard()
        except:
            pass
        return ""
    
    def check(self, source_window_title, user_pressed_copy=False):
        """
        Check clipboard. ONLY returns event if user pressed Ctrl+C.
        """
        # THE FIX: Only proceed if user actually pressed Ctrl+C
        if not user_pressed_copy:
            return None
        
        current_seq = ctypes.windll.user32.GetClipboardSequenceNumber()
        
        # Check if clipboard actually changed
        if current_seq == self.last_sequence:
            return None
        
        self.last_sequence = current_seq
        formats = self._get_clipboard_formats()
        
        event = {
            "timestamp": time.time(),
            "source": source_window_title
        }
        
        if "FILES" in formats:
            count = self._get_file_count()
            event["detail"] = f"Copied {count} file(s)"
        elif "TEXT" in formats:
            preview = self._get_text_preview(30)
            if preview:
                event["detail"] = f"Copied: \"{preview}...\""
            else:
                event["detail"] = "Copied text"
        elif "IMAGE" in formats:
            event["detail"] = "Copied image"
        else:
            event["detail"] = "Copied data"
        
        self.pending_events.append(event)
        return event
    
    def get_batch_summary(self, flush_interval=3.0):
        """Get batched summary of clipboard events."""
        now = time.time()
        if now - self.last_flush < flush_interval:
            return None
        
        if not self.pending_events:
            self.last_flush = now
            return None
        
        count = len(self.pending_events)
        summary = f"{count} item(s) copied" if count > 1 else self.pending_events[0]["detail"]
        
        self.pending_events = []
        self.last_flush = now
        
        return summary


# ==========================================
# 4. DRAG & DROP INFERENCE (Unchanged)
# ==========================================

class DragInference:
    """Infers drag-and-drop actions from mouse state."""
    
    DRAG_THRESHOLD = 20
    
    def __init__(self):
        self.drag_active = False
        self.drag_start_pos = None
        self.drag_start_window = None
        self.last_mouse_state = False
    
    def _is_left_button_down(self):
        return bool(user32.GetAsyncKeyState(0x01) & 0x8000)
    
    def update(self, cursor_pos, focused_window_title):
        """Update drag state. Returns event if a drop occurred."""
        left_down = self._is_left_button_down()
        event = None
        
        if left_down and not self.last_mouse_state:
            self.drag_start_pos = (cursor_pos["x"], cursor_pos["y"])
            self.drag_start_window = focused_window_title
            self.drag_active = False
        
        if left_down and self.drag_start_pos:
            dx = abs(cursor_pos["x"] - self.drag_start_pos[0])
            dy = abs(cursor_pos["y"] - self.drag_start_pos[1])
            if dx > self.DRAG_THRESHOLD or dy > self.DRAG_THRESHOLD:
                self.drag_active = True
        
        if not left_down and self.last_mouse_state and self.drag_active:
            if self.drag_start_window != focused_window_title:
                event = {
                    "type": "DRAG_DROP",
                    "from": self.drag_start_window,
                    "to": focused_window_title
                }
            self.drag_active = False
            self.drag_start_pos = None
            self.drag_start_window = None
        
        self.last_mouse_state = left_down
        return event


# ==========================================
# 5. KEYBOARD DETECTION (Unchanged)
# ==========================================
VK_SHIFT, VK_CONTROL, VK_ALT = 0x10, 0x11, 0x12
VK_RETURN, VK_ESCAPE = 0x0D, 0x1B
VK_S, VK_Z, VK_C, VK_V = 0x53, 0x5A, 0x43, 0x56

def get_keyboard_state():
    return {
        "shift": bool(user32.GetAsyncKeyState(VK_SHIFT) & 0x8000),
        "ctrl": bool(user32.GetAsyncKeyState(VK_CONTROL) & 0x8000),
        "alt": bool(user32.GetAsyncKeyState(VK_ALT) & 0x8000),
        "enter": bool(user32.GetAsyncKeyState(VK_RETURN) & 0x8000),
        "escape": bool(user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000),
    }

def detect_key_action(keys):
    """Detect meaningful key actions."""
    if keys["enter"]:
        return "ENTER_PRESSED"
    if keys["escape"]:
        return "ESCAPE_PRESSED"
    if keys["ctrl"]:
        if user32.GetAsyncKeyState(VK_S) & 0x8000:
            return "SAVE_TRIGGERED"
        if user32.GetAsyncKeyState(VK_Z) & 0x8000:
            return "UNDO_TRIGGERED"
        if user32.GetAsyncKeyState(VK_C) & 0x8000:
            return "COPY_TRIGGERED"
        if user32.GetAsyncKeyState(VK_V) & 0x8000:
            return "PASTE_TRIGGERED"
    return None


# ==========================================
# 6. UI AUTOMATION (Unchanged)
# ==========================================
try:
    import comtypes.client
    from comtypes import COMError
    
    UIA_AVAILABLE = True
    uia = comtypes.client.CreateObject("{ff48dba4-60ef-4201-aa87-54103eef594e}")
    uia._QueryInterface_(comtypes.IUnknown)
    from comtypes.gen.UIAutomationClient import IUIAutomation
    uia = uia.QueryInterface(IUIAutomation)
    
except Exception as e:
    UIA_AVAILABLE = False
    uia = None

def get_focused_element():
    if not UIA_AVAILABLE:
        return {"available": False}
    
    try:
        focused = uia.GetFocusedElement()
        if focused:
            return {
                "available": True,
                "type": focused.CurrentLocalizedControlType or "Unknown",
                "name": (focused.CurrentName or "")[:50],
                "class": focused.CurrentClassName or ""
            }
    except:
        pass
    
    return {"available": True, "type": "Unknown", "name": "", "class": ""}


# ==========================================
# 7. IDLE DETECTOR (New in v4.1)
# ==========================================

class IdleDetector:
    """Detects user idle state and adjusts loop speed."""
    
    IDLE_THRESHOLD = 30  # seconds
    AFK_THRESHOLD = 300  # 5 minutes
    
    def __init__(self):
        self.last_input_time = time.time()
        self.last_cursor = None
    
    def update(self, cursor, keys):
        """Update with current input state."""
        has_input = False
        
        # Check keyboard
        if any(keys.values()):
            has_input = True
        
        # Check cursor movement
        if self.last_cursor:
            dx = abs(cursor["x"] - self.last_cursor["x"])
            dy = abs(cursor["y"] - self.last_cursor["y"])
            if dx > 5 or dy > 5:
                has_input = True
        
        if has_input:
            self.last_input_time = time.time()
        
        self.last_cursor = cursor.copy()
    
    def get_loop_interval(self):
        """Get recommended loop interval based on idle time."""
        idle_duration = time.time() - self.last_input_time
        
        if idle_duration > self.AFK_THRESHOLD:
            return 2.0  # AFK: 2 seconds
        elif idle_duration > self.IDLE_THRESHOLD:
            return 0.5  # Idle: 500ms
        else:
            return 0.1  # Active: 100ms
    
    def is_idle(self):
        """Check if user is currently idle."""
        return (time.time() - self.last_input_time) > self.IDLE_THRESHOLD


# ==========================================
# 8. TIERED LOOP CONTROLLER (New in v4.1)
# ==========================================

class TieredLoop:
    """
    Manages tiered checking intervals.
    Tier 1: 100ms - Cursor, keyboard
    Tier 2: 300ms - Focus check
    Tier 3: 3s - Peripheral scan (or on focus change)
    """
    
    def __init__(self):
        self.last_tier2 = 0
        self.last_tier3 = 0
        self.last_focus_hwnd = None
        self.cached_desktop_state = None
    
    def should_check_focus(self):
        """Tier 2: Check every 300ms."""
        now = time.time()
        if now - self.last_tier2 >= 0.3:
            self.last_tier2 = now
            return True
        return False
    
    def should_scan_peripherals(self, current_focus_hwnd):
        """Tier 3: Check every 3s OR on focus change."""
        now = time.time()
        focus_changed = (current_focus_hwnd != self.last_focus_hwnd)
        
        if focus_changed:
            self.last_focus_hwnd = current_focus_hwnd
            self.last_tier3 = now
            return True
        
        if now - self.last_tier3 >= 3.0:
            self.last_tier3 = now
            return True
        
        return False


# ==========================================
# 9. HUMAN TRANSLATOR (v4.1 - Cleaner)
# ==========================================

def translate_to_human(desktop_state, trigger=None, clipboard_summary=None, drag_event=None):
    """Convert state to human-readable output."""
    lines = []
    
    # Focus
    if desktop_state.get("focused"):
        title = desktop_state["focused"]["title"]
        if desktop_state.get("is_fullscreen"):
            lines.append(f"🎯 FULLSCREEN: {title[:45]}")
        elif "*" in title:
            lines.append(f"🎯 FOCUS: {title[:45]} (UNSAVED)")
        else:
            lines.append(f"🎯 FOCUS: {title[:45]}")
    
    # Peripheral (only if not fullscreen)
    if not desktop_state.get("is_fullscreen") and desktop_state.get("peripheral"):
        periph_titles = [p["title"][:25] for p in desktop_state["peripheral"][:3]]
        if periph_titles:
            lines.append(f"👁️ VISIBLE: {' | '.join(periph_titles)}")
    
    # Keyboard action (INSTANT - not batched)
    if trigger:
        action_map = {
            "ENTER_PRESSED": "⏎ ENTER",
            "ESCAPE_PRESSED": "✖ ESCAPE",
            "SAVE_TRIGGERED": "💾 SAVED",
            "UNDO_TRIGGERED": "↩️ UNDO",
            "COPY_TRIGGERED": "📋 COPY",
            "PASTE_TRIGGERED": "📥 PASTE",
        }
        if trigger in action_map:
            lines.append(f"   >> {action_map[trigger]}")
    
    # Clipboard (batched summary)
    if clipboard_summary:
        lines.append(f"   >> 📋 {clipboard_summary}")
    
    # Drag event
    if drag_event:
        lines.append(f"   >> 🔀 Dragged from '{drag_event['from'][:20]}' → '{drag_event['to'][:20]}'")
    
    return "\n".join(lines)


# ==========================================
# 10. LIVE WATCHER (v4.1 - Efficient)
# ==========================================

def live_watch():
    print("\n" + "="*70)
    print("   OPTIC NERVE v4.1: EFFICIENT MODE")
    print("   Tiered loops | Fullscreen gate | Idle slowdown")
    print("   Press Ctrl+C to stop.")
    print("="*70 + "\n")
    
    # Initialize subsystems
    window_map = WindowMap()
    clipboard_scribe = ClipboardScribe()
    drag_inference = DragInference()
    idle_detector = IdleDetector()
    tiered_loop = TieredLoop()
    
    cached_desktop_state = None
    last_output = ""
    
    while True:
        try:
            # Get dynamic interval based on idle state
            interval = idle_detector.get_loop_interval()
            
            # TIER 1: Always (fast checks)
            cursor = get_cursor_position()
            keys = get_keyboard_state()
            idle_detector.update(cursor, keys)
            
            # Detect key action
            trigger = detect_key_action(keys)
            
            # Get current focus
            foreground_hwnd = user32.GetForegroundWindow()
            
            # TIER 2: Focus check (300ms)
            if tiered_loop.should_check_focus():
                # Check if we need tier 3
                if tiered_loop.should_scan_peripherals(foreground_hwnd):
                    cached_desktop_state = window_map.scan()
                elif cached_desktop_state is None:
                    cached_desktop_state = window_map.scan()
            
            # Ensure we have state
            if cached_desktop_state is None:
                cached_desktop_state = window_map.scan()
            
            focused_title = cached_desktop_state["focused"]["title"] if cached_desktop_state.get("focused") else ""
            
            # Clipboard: Only check if Ctrl+C was pressed
            user_pressed_copy = (trigger == "COPY_TRIGGERED")
            clipboard_scribe.check(focused_title, user_pressed_copy)
            
            # Get batched clipboard summary (every 3s)
            clipboard_summary = clipboard_scribe.get_batch_summary()
            
            # Drag detection
            drag_event = drag_inference.update(cursor, focused_title)
            
            # Generate output
            output = translate_to_human(
                cached_desktop_state,
                trigger,
                clipboard_summary,
                drag_event
            )
            
            # Only print if something changed
            if trigger or clipboard_summary or drag_event or output != last_output:
                print(f"\n{'─'*70}")
                print(f"[{time.strftime('%H:%M:%S')}]")
                print(f"{'─'*70}")
                print(output)
                last_output = output
            elif not idle_detector.is_idle():
                # Show watching indicator only when not idle
                print(f"\r[{time.strftime('%H:%M:%S')}] ({cursor['x']:4},{cursor['y']:4})    ", end="", flush=True)
            
            time.sleep(interval)
            
        except KeyboardInterrupt:
            print("\n\n[OPTIC NERVE v4.1] Shutting down...")
            break


def snapshot():
    print("\n[OPTIC NERVE v4.1] Taking snapshot...\n")
    
    window_map = WindowMap()
    desktop_state = window_map.scan(force_full=True)
    
    print(translate_to_human(desktop_state, None, None, None))
    print("\n[RAW STATE]:")
    print(json.dumps(desktop_state, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    print("\nOPTIC NERVE v4.1 - Choose Mode:")
    print("  1. Live Watch (Efficient)")
    print("  2. Single Snapshot")
    
    choice = input("\nEnter choice (1 or 2): ").strip()
    
    if choice == "1":
        live_watch()
    else:
        snapshot()
