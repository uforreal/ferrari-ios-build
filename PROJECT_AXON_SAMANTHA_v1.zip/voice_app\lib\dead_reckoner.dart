/// Dead Reckoner: Local pattern matching to avoid LLM calls
class DeadReckoner {
  final Map<String, Map<String, dynamic>> _patterns = {
    // Browser patterns
    'chrome_copy': {
      'match': {'app': 'chrome', 'trigger': 'COPY_TRIGGERED'},
      'speech': 'Copied from browser.',
      'confidence': 0.9,
    },
    'arc_focus': {
      'match': {'app': 'arc'},
      'speech': 'Research mode active.',
      'confidence': 0.85,
    },

    // Dev patterns
    'antigravity_save': {
      'match': {'app': 'antigravity', 'trigger': 'SAVE_TRIGGERED'},
      'speech': 'Code saved. Ready to build?',
      'confidence': 0.95,
    },
    'cmd_focus': {
      'match': {'app': 'cmd'},
      'speech': 'Terminal ready.',
      'confidence': 0.9,
    },
    'powershell_focus': {
      'match': {'app': 'powershell'},
      'speech': 'PowerShell active.',
      'confidence': 0.9,
    },

    // Tools
    'geoport_focus': {
      'match': {'app': 'geoport'},
      'speech': 'Geoport opened. Testing location?',
      'confidence': 0.9,
    },
  };

  int get patternCount => _patterns.length;

  Map<String, dynamic>? predict(Map<String, dynamic> context) {
    final currentApp = (context['current_app'] as String? ?? '').toLowerCase();
    final trigger = context['trigger'] as String?;

    // Try to match patterns
    for (var pattern in _patterns.values) {
      final match = pattern['match'] as Map<String, dynamic>;
      final appMatch = match['app'] as String?;
      final triggerMatch = match['trigger'] as String?;

      bool matches = true;

      if (appMatch != null && !currentApp.contains(appMatch)) {
        matches = false;
      }

      if (triggerMatch != null && trigger != triggerMatch) {
        matches = false;
      }

      if (matches) {
        return {
          'speech': pattern['speech'],
          'confidence': pattern['confidence'],
          'source': 'dead_reckoning',
        };
      }
    }

    // No match found
    return null;
  }

  void learnPattern(String name, Map<String, dynamic> pattern) {
    _patterns[name] = pattern;
    print('[Dead Reckoner] ✓ Learned pattern: $name');
  }
}
