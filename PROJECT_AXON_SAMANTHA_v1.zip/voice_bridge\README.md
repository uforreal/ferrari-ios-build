# 🧠 Project AXON: Voice Bridge

**Real-time AI companion that speaks to you through your iPhone based on your PC activity.**

---

## Architecture

```
┌─────────────────────────────────────────┐
│ PC: PERCEPTION & DECISION               │
├─────────────────────────────────────────┤
│                                         │
│  Optic Nerve v4.1 (Eyes)               │
│         ↓                               │
│  Fireball Engine (Decision)            │
│         ↓                               │
│  IPA Gateway (Enrichment)              │
│         ↓                               │
│  AXON Server (RAMEN Transport)         │
│                                         │
└─────────────────────────────────────────┘
              ↓ WebSocket
┌─────────────────────────────────────────┐
│ iPhone: ACTION                          │
├─────────────────────────────────────────┤
│                                         │
│  AXON Client (Receiver)                │
│         ↓                               │
│  Dead Reckoner (Pattern Matcher)       │
│         ↓                               │
│  TTS Service (Voice Output) 🔊         │
│                                         │
└─────────────────────────────────────────┘
```

---

## Quick Start

### 1. Setup PC Server

```bash
cd voice_bridge
pip install websockets google-generativeai python-dotenv

# Create .env file with your API key
cp .env.example .env
# Edit .env and add: GEMINI_API_KEY=your_key_here

# Run the system
python run_system.py
```

### 2. Setup iPhone App

```bash
cd voice_app
flutter pub get
flutter run
```

### 3. Test

1. PC will show: `AXON Server listening on ws://0.0.0.0:8765`
2. iPhone will show: `Connected to AXON`
3. Switch between apps on PC
4. iPhone will speak context changes

---

## H3 Hexagons (Your Workflow)

| Hex | Apps |
|-----|------|
| **RESEARCH** | Arc, Chrome, Edge, Comet |
| **DEV** | Antigravity, cmd, PowerShell, GitHub Desktop |
| **TOOLS** | Geoport |

---

## Files

- `optic_nerve.py` - Perception layer (cloned from v4.1)
- `fireball_engine.py` - Decision logic with H3 contexts
- `ipa_gateway.py` - Data enrichment
- `axon_server.py` - RAMEN WebSocket server
- `run_system.py` - Main orchestrator

---

## Security

**Never commit `.env` file!** It contains your API key.
