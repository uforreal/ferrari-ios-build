"""
IPA GATEWAY: Data Enrichment Layer
===================================
Takes minimal event signals from Fireball and enriches them
with full context before pushing to iPhone via RAMEN.
"""

import time
from typing import Dict, Optional
import os
from dotenv import load_dotenv

# Try to import Gemini (optional for Dead Reckoning fallback)
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

load_dotenv()

class IPAGateway:
    """
    Enriches minimal event signals into full contextual payloads.
    Optional LLM integration for unknown patterns.
    """
    
    def __init__(self):
        self.recent_actions = []  # Last 10 actions
        self.last_clipboard = None
        
        # Setup Gemini if API key present
        self.llm_enabled = False
        if GEMINI_AVAILABLE and os.getenv("GEMINI_API_KEY"):
            try:
                genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
                # Try the most stable version
                self.model = genai.GenerativeModel('gemini-1.5-flash')
                self.llm_enabled = True
                print("[IPA Gateway] ✓ Gemini LLM enabled (Conversational Mode)")
            except Exception as e:
                print(f"[IPA Gateway] ⚠ Gemini setup failed: {e}")
    
    def log_action(self, action: Dict):
        """Log action for context building"""
        self.recent_actions.append({
            "time": time.time(),
            "action": action
        })
        
        # Keep only last 10
        if len(self.recent_actions) > 10:
            self.recent_actions.pop(0)
    
    def enrich_event(self, event: Dict, priority: int) -> Dict:
        """
        Convert minimal event into full payload for iPhone.
        """
        # Build context
        context = {
            "current_app": event.get("focused_app", ""),
            "trigger": event.get("trigger"),
            "recent_actions": self.recent_actions[-3:],
            "timestamp": time.time()
        }
        
        # Generate speech text
        speech_text = self._generate_speech(event, priority)
        
        payload = {
            "type": "speak",
            "text": speech_text,
            "priority": priority,
            "context": context,
            "mood": "helpful"
        }
        
        return payload
    
    def _generate_speech(self, event: Dict, priority: int) -> str:
        """
        Generate what the AI should say.
        Uses templates first, LLM fallback if needed.
        """
        app = event.get("focused_app", "").lower()
        trigger = event.get("trigger")
        
        # Template-based responses for specific triggers
        if trigger == "SAVE_TRIGGERED" and "antigravity" in app:
            return "Saved that for you. Ready to run the build?"
            
        if trigger == "COPY_TRIGGERED":
             return "Snippet captured. Want me to check that?"

        # Use LLM for conversational context switching
        if self.llm_enabled and priority > 40:
            return self._llm_generate(event)
        
        # Human-like fallback if LLM is off
        return f"Checking in on {event.get('focused_app', 'your current task')}."
    
    def _llm_generate(self, event: Dict) -> str:
        """
        Use Gemini to generate conversational response with safety off.
        """
        try:
            # User personification
            prompt = f"""You are a helpful AI sidekick. The person you are helping is working on their PC.
            Current Focus: {event.get('focused_app', 'unknown app')}.
            Recent context: Switch of windows.
            
            Say something short, clever, and very human. Avoid 'You have switched to'. 
            Try things like 'Back to the code?', 'Doing some deep research?', 'Checking the terminal?'.
            Be brief (max 10 words)."""

            # Set safety settings to none to avoid "Changed context" blocks
            safety_settings = [
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
            ]

            response = self.model.generate_content(
                prompt, 
                safety_settings=safety_settings
            )
            
            if response and response.text:
                return response.text.strip()
            return "Switched gears."
            
        except Exception as e:
            # Fallback to different model name if 404
            if "404" in str(e):
                try:
                    self.model = genai.GenerativeModel('gemini-pro')
                    return self._llm_generate(event)
                except:
                    pass
            print(f"[IPA Gateway] LLM error: {e}")
            return f"Opening {event.get('focused_app', 'work')}."

