import asyncio
import websockets
import json

async def send_test():
    uri = "ws://192.168.1.81:8765"
    async with websockets.connect(uri) as websocket:
        print("Connected to server!")
        
        while True:
            text = input("Enter text to speak (or 'q' to quit): ")
            if text == 'q':
                break
                
            msg = json.dumps({"type": "speak", "text": text})
            await websocket.send(msg)
            print(f"Sent: {text}")

if __name__ == "__main__":
    try:
        asyncio.run(send_test())
    except:
        print("Could not connect. Is run_system.py running?")
