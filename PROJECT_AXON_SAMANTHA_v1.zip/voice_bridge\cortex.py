"""
CORTEX: The Living Librarian
============================
Manages the "Tiered Knowledge" of the system.
- Checks local library first.
- If missing, fetching 'Online' (Simulated) and Digests.
- Enforces decay rules (Guardrails).
"""

import os
import json
import time
from digester import Digester

class Cortex:
    def __init__(self, root_path="library"):
        self.root = root_path
        self.core_path = os.path.join(root_path, "core")
        self.transient_path = os.path.join(root_path, "transient")
        self.digester = Digester()
        
        # Ensure library exists
        os.makedirs(self.core_path, exist_ok=True)
        os.makedirs(self.transient_path, exist_ok=True)
        print(f"[Cortex] Library initialized at '{self.root}'")

    def _get_path(self, topic, tier):
        filename = f"{topic.lower().replace(' ', '_')}.json"
        if tier == 1:
            return os.path.join(self.core_path, filename)
        else:
            return os.path.join(self.transient_path, filename)

    def query(self, topic, tier=1):
        """
        The Main Interface.
        1. Checks local.
        2. If missing, Learns (Digests).
        3. Returns Knowledge.
        """
        path = self._get_path(topic, tier)
        
        # 1. Local Check
        if os.path.exists(path):
            print(f"[Cortex] Found '{topic}' in Local Library (Tier {tier}). Reading...")
            with open(path, 'r') as f:
                data = json.load(f)
            
            # Decay Logic (For Tier 2)
            if tier == 2:
                age_hours = (time.time() - os.path.getmtime(path)) / 3600
                if age_hours > 24:
                    print(f"[Cortex] '{topic}' is Rotting (>{int(age_hours)}h old). Deleting...")
                    os.remove(path)
                    return self.query(topic, tier) # Re-learn
            
            return data

        # 2. Learning Phase (Simulated API Call)
        print(f"[Cortex] '{topic}' NOT found locally. Fetching from 'Cloud'...")
        
        # Simulate Network Lag
        time.sleep(1.5) 
        
        # Simulate "Downloading" raw text
        raw_text = f"This is the downloaded manual content for {topic}..."
        
        # Digest it
        knowledge = self.digester.digest_text(raw_text, topic)
        
        # 3. Store It
        with open(path, 'w') as f:
            json.dump(knowledge, f, indent=2)
        print(f"[Cortex] '{topic}' Saved to Library.")
        
        return knowledge

    def run_guardrails(self):
        """Clean up Tier 2 trash."""
        print("[Cortex] Running Guardrails (Trash Collection)...")
        # Logic to delete old files in transient folder
        # ... (simplified for demo)

if __name__ == "__main__":
    brain = Cortex()
    
    # Test Tier 1 (SolidWorks - Permanent)
    print("\n--- TEST: Core Knowledge ---")
    k1 = brain.query("SolidWorks Sketching", tier=1)
    print(f"Action: {k1['data']['key_actions'][0]}")

    # Test Tier 2 (Movie - Transient)
    print("\n--- TEST: Transient Knowledge ---")
    k2 = brain.query("Inception Movie", tier=2)
    print(f"Summary: {k2['data']['summary']}")
    
    # Test Recall (Should be instant)
    print("\n--- TEST: Recall (Instant) ---")
    start = time.time()
    k3 = brain.query("SolidWorks Sketching", tier=1)
    print(f"Recall Time: {time.time() - start:.4f}s")
