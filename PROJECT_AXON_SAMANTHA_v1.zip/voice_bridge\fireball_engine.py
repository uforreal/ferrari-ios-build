"""
FIREBALL ENGINE: The Decision Layer
====================================
Determines WHEN and WHAT to push to the iPhone based on:
- H3 Context Hexagons (workflow zones)
- User mode (Flow/Idle/Transition)
- Priority scoring
- Rate limiting
"""

import time
from enum import Enum
from typing import Dict, List, Optional

class WorkflowHex(Enum):
    """H3-inspired workflow contexts"""
    RESEARCH = "research"  # Browsers
    DEV = "dev"            # Code, terminal, GitHub
    TOOLS = "tools"        # Specialized utilities
    UNKNOWN = "unknown"

class UserMode(Enum):
    """Current user cognitive state"""
    FLOW = "flow"          # Deep work, don't interrupt
    IDLE = "idle"          # Inactive, low priority
    TRANSITION = "transition"  # Context switching, high priority

class FireballEngine:
    """
    The brain that decides if an event is worth pushing to iPhone.
    """
    
    # APP KEYWORDS (BROAD & MULTI-LANGUAGE)
    APP_KEYWORDS = {
        # Research Hex
        "arc": WorkflowHex.RESEARCH,
        "chrome": WorkflowHex.RESEARCH,
        "edge": WorkflowHex.RESEARCH,
        "msedge": WorkflowHex.RESEARCH,
        "comet": WorkflowHex.RESEARCH,
        "google": WorkflowHex.RESEARCH,
        "youtube": WorkflowHex.RESEARCH,
        "navigateur": WorkflowHex.RESEARCH, # French
        
        # Dev Hex
        "antigravity": WorkflowHex.DEV,
        "cmd": WorkflowHex.DEV,
        "powershell": WorkflowHex.DEV,
        "invite": WorkflowHex.DEV,     # Invite de commandes (French)
        "code": WorkflowHex.DEV,       # VS Code
        "github": WorkflowHex.DEV,
        "terminal": WorkflowHex.DEV,
        "console": WorkflowHex.DEV,
        
        # Tools Hex
        "geoport": WorkflowHex.TOOLS,
    }
    
    # Rate limiting config
    MIN_PUSH_INTERVAL = 3.0  
    FLOW_MODE_THRESHOLD = 300  
    
    def __init__(self):
        self.last_push_time = 0
        self.last_hex = WorkflowHex.UNKNOWN
        self.last_app = ""
        self.last_transition_time = time.time()
    
    def _get_hex_from_app(self, app_title: str) -> WorkflowHex:
        """Map app title to workflow hex"""
        if not app_title:
            return WorkflowHex.UNKNOWN
            
        app_lower = app_title.lower()
        
        for key, hex_type in self.APP_KEYWORDS.items():
            if key in app_lower:
                return hex_type
        
        return WorkflowHex.UNKNOWN
    
    def _calculate_user_mode(self, current_app: str, time_in_app: float) -> UserMode:
        """Determine user's cognitive state"""
        if current_app == self.last_app and time_in_app > self.FLOW_MODE_THRESHOLD:
            return UserMode.FLOW
        
        if current_app != self.last_app:
            return UserMode.TRANSITION
        
        return UserMode.IDLE
    
    def _calculate_priority(self, event: Dict, current_hex: WorkflowHex, user_mode: UserMode) -> int:
        """Score event priority (0-100)"""
        priority = 50  # Base
        
        if current_hex != self.last_hex:
            priority += 30
        
        if event.get("trigger") in ["SAVE_TRIGGERED", "COPY_TRIGGERED"]:
            priority += 20
        
        if user_mode == UserMode.FLOW:
            priority -= 40
        
        return max(0, min(100, priority))
    
    def should_push(self, event: Dict) -> tuple[bool, Optional[int]]:
        """
        Main decision function.
        Returns: (should_push: bool, priority: Optional[int])
        """
        now = time.time()
        app_title = event.get("focused_app", "")
        trigger = event.get("trigger")
        
        # Determine context
        current_hex = self._get_hex_from_app(app_title)
        time_in_app = now - self.last_transition_time
        user_mode = self._calculate_user_mode(app_title, time_in_app)
        priority = self._calculate_priority(event, current_hex, user_mode)
        
        time_since_last_push = now - self.last_push_time
        should_push = False
        
        # LOGIC:
        # 1. Context shift (App change) -> ALWAYS push if focus is actual window
        if app_title != self.last_app and app_title != "":
            should_push = True
            print(f"[Fireball] Focus: '{self.last_app}' -> '{app_title}' (Hex: {current_hex.name})")
        
        # 2. Intent Trigger (Save/Copy)
        elif trigger and time_since_last_push > self.MIN_PUSH_INTERVAL:
            should_push = True
            print(f"[Fireball] Trigger: {trigger} in {app_title}")

        # Update persistent state
        if app_title != self.last_app:
            self.last_transition_time = now
        
        self.last_app = app_title
        self.last_hex = current_hex
        
        if should_push:
            self.last_push_time = now
            
        return should_push, priority

    def get_context_description(self, event: Dict) -> str:
        app_title = event.get("focused_app", "")
        hex_type = self._get_hex_from_app(app_title)
        
        context_map = {
            WorkflowHex.RESEARCH: "Research mode",
            WorkflowHex.DEV: "Building mode",
            WorkflowHex.TOOLS: "Tool usage",
            WorkflowHex.UNKNOWN: "Exploring"
        }
        
        return context_map.get(hex_type, "Active")
