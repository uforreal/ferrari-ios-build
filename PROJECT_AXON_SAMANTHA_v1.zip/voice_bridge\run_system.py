"""
PROJECT AXON: Voice Bridge (Integrated Vibe Edition)
====================================================
Combines the "Stable" Focus Detection with the "Vibe" Resonance Engine.
- Focus Changes -> Speech
- Social Reflexes (Hmm, Reassurance) -> Speech
- Keyboard (Ctrl+S/Z) -> Speech
"""

import time
import ctypes
import asyncio
import websockets
import json
import random
from ctypes import wintypes
import psutil

# Import Modules
from resonance_engine import ResonanceEngine
from optic_nerve import get_keyboard_state, detect_key_action

# ==========================================
# WINDOWS API (Mini-Eyeball)
# ==========================================
user32 = ctypes.windll.user32

def get_focus():
    """Get current focused window info."""
    hwnd = user32.GetForegroundWindow()
    length = user32.GetWindowTextLengthW(hwnd) + 1
    buffer = ctypes.create_unicode_buffer(length)
    user32.GetWindowTextW(hwnd, buffer, length)
    title = buffer.value
    
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    try:
        process = psutil.Process(pid.value).name()
    except:
        process = "unknown"
    return process, title

# ==========================================
# SPEECH GENERATOR
# ==========================================
APP_SPEECH = {
    "arc.exe": "Research mode.",
    "chrome.exe": "Browsing.",
    "msedge.exe": "Edge browser.",
    "firefox.exe": "Firefox open.",
    "antigravity.exe": "Back to coding.",
    "code.exe": "VS Code.",
    "cmd.exe": "Terminal.",
    "powershell.exe": "PowerShell.",
    "explorer.exe": "File explorer.",
    "discord.exe": "Discord.",
    "spotify.exe": "Music time.",
}

IGNORE_APPS = {"searchapp.exe", "searchhost.exe", "shellexperiencehost.exe"}

def get_speech(process_name):
    lower = process_name.lower()
    if lower in IGNORE_APPS: return None
    for app, speech in APP_SPEECH.items():
        if app in lower: return speech
    return f"Opening {process_name.replace('.exe', '').replace('-', ' ')}."

# ==========================================
# MAIN SYSTEM
# ==========================================
class ProjectAXON:
    def __init__(self):
        self.clients = set()
        self.last_process = ""
        self.running = True
        
        # Initialize the Vibe Brain
        self.resonance = ResonanceEngine()
        
    async def handle_client(self, websocket):
        print(f"[AXON] ✓ Client connected: {websocket.remote_address}")
        self.clients.add(websocket)
        try:
            # Send initial greeting
            await websocket.send(json.dumps({"type": "speak", "text": "Systems online. Resonance engine active."}))
            async for msg in websocket: pass
        except: pass
        finally:
            self.clients.discard(websocket)
            print(f"[AXON] ✗ Client disconnected")
    
    async def broadcast(self, text):
        if not self.clients: return
        message = json.dumps({"type": "speak", "text": text})
        for client in list(self.clients):
            try: await client.send(message)
            except: self.clients.discard(client)
            
    async def perception_loop(self):
        print("[AXON] Vibe System Active. Watching...\n")
        
        while self.running:
            try:
                # 1. OPTIC NERVE: Get Raw Signals
                process, title = get_focus()
                keys = get_keyboard_state()
                trigger = detect_key_action(keys)
                
                # 2. EVENT: Focus Change
                if process != self.last_process and process != "":
                    speech = get_speech(process)
                    if speech:
                        print(f"[FOCUS] {self.last_process} → {process}")
                        await self.broadcast(speech)
                    self.last_process = process

                # 3. RESONANCE ENGINE: Process Vibe
                # Feed the trigger (e.g., "SAVE_TRIGGERED") to the engine
                # The engine also calculates idle time internally based on calls
                vibe_reflex = self.resonance.process_signal(trigger)
                
                if vibe_reflex:
                    print(f"[VIBE] » {vibe_reflex}")
                    await self.broadcast(vibe_reflex)
                
                await asyncio.sleep(0.1)  # 10 Hz Loop
                
            except Exception as e:
                print(f"[ERROR] {e}")
                await asyncio.sleep(1)
    
    async def run(self):
        print("╔═══════════════════════════════════════════════════════════╗")
        print("║   PROJECT AXON: Integrated Vibe System                   ║")
        print("║   ws://0.0.0.0:8765                                      ║")
        print("╚═══════════════════════════════════════════════════════════╝")
        
        server = await websockets.serve(self.handle_client, "0.0.0.0", 8765)
        await self.perception_loop()

if __name__ == "__main__":
    system = ProjectAXON()
    try:
        asyncio.run(system.run())
    except KeyboardInterrupt:
        print("\n[AXON] Shutting down...")
