"""
VERIFY VIBE: Simulation Test (Strict)
=====================================
Simulates user behavior with manual state resets to bypass Cooldowns
and Startup Timers, ensuring pure logic validation.
"""

import time
from resonance_engine import ResonanceEngine

def test_vibe_logic():
    print("[-] Initializing Resonance Engine...")
    engine = ResonanceEngine("vibe_map.json")
    
    # KILL SWITCHES: Bypass Startup and Cooldowns for testing
    engine.start_time = time.time() - 1000  # Kill "Greeting" (New Presence)
    
    # Test 1: High Velocity (Flow Mode) - Silence Expected
    print("\n[TEST 1] High Activity (Flow Mode)...")
    engine.last_speech_time = 0 # Reset cooldown
    for i in range(30):
        engine.process_signal(trigger=None) 
        
    reflex = engine.process_signal() 
    print(f"   -> Result: {reflex} (Expected: None/Silence)")
    
    # Test 2: Instant Stop (Curiosity)
    print("\n[TEST 2] Sudden Silence (30s)...")
    engine.last_speech_time = 0 # Reset cooldown
    engine.action_history = []  # Clear velocity
    engine.last_action_time = time.time() - 30.1 # Set idle time
    
    reflex = engine.process_signal()
    print(f"   -> Result: '{reflex}' (Expected: Hmm.../Thinking?)")
    
    # Test 3: Undo Spam (Reassurance)
    print("\n[TEST 3] Undo Spam (Frustration)...")
    engine.last_speech_time = 0 # Reset cooldown
    engine.action_history = [] 
    engine.last_action_time = time.time() # Reset idle time
    
    results = []
    for i in range(5):
        res = engine.process_signal(trigger="UNDO_TRIGGERED")
        if res: results.append(res)
    
    print(f"   -> Result: '{results[-1] if results else None}' (Expected: Reassurance)")

    # Test 4: Save (Achievement)
    print("\n[TEST 4] Save Trigger...")
    engine.last_speech_time = 0 # Reset cooldown
    engine.action_history = []
    
    reflex = engine.process_signal(trigger="SAVE_TRIGGERED")
    print(f"   -> Result: '{reflex}' (Expected: Secure/Saved)")

if __name__ == "__main__":
    test_vibe_logic()
