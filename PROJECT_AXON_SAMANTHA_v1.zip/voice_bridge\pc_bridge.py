import asyncio
import websockets
import json
import win32com.client

# The "Daniel" or "Kate" voice from your Windows settings
speaker = win32com.client.Dispatch("SAPI.SpVoice")

async def run_bridge():
    url = "ws://192.168.1.81:8765"
    print(f"[BRIDGE] Connecting to {url}...")
    
    while True:
        try:
            async with websockets.connect(url) as websocket:
                print("[BRIDGE] ✓ Connected to AXON Server")
                
                async for message in websocket:
                    data = json.loads(message)
                    if data.get("type") == "speak":
                        text = data.get("text", "")
                        print(f"[AI]: {text}")
                        # SVSFlagsAsync = 1 (speak in background)
                        speaker.Speak(text, 1) 
                        
        except Exception as e:
            print(f"[BRIDGE] ✗ Connection failed: {e}. Retrying in 3s...")
            await asyncio.sleep(3)

if __name__ == "__main__":
    try:
        asyncio.run(run_bridge())
    except KeyboardInterrupt:
        print("\n[BRIDGE] Offline.")
