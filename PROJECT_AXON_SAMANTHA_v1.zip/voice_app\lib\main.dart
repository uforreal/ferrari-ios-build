import 'package:flutter/material.dart';
import 'axon_client.dart';
import 'tts_service.dart';
import 'dead_reckoner.dart';

void main() {
  runApp(const VoiceBridgeApp());
}

class VoiceBridgeApp extends StatelessWidget {
  const VoiceBridgeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AXON Voice Bridge',
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF00D9FF),
        scaffoldBackgroundColor: const Color(0xFF0A0E27),
      ),
      home: const VoiceBridgePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class VoiceBridgePage extends StatefulWidget {
  const VoiceBridgePage({super.key});

  @override
  State<VoiceBridgePage> createState() => _VoiceBridgePageState();
}

class _VoiceBridgePageState extends State<VoiceBridgePage> {
  late AXONClient _axonClient;
  late TTSService _ttsService;
  late DeadReckoner _deadReckoner;

  bool _isConnected = false;
  String _lastMessage = "Waiting for connection...";
  String _currentContext = "Unknown";
  int _messageCount = 0;

  @override
  void initState() {
    super.initState();
    
    // Initialize services
    _ttsService = TTSService();
    _deadReckoner = DeadReckoner();
    _axonClient = AXONClient(
      serverUrl: 'ws://192.168.1.81:8765', // Updated to match your actual PC IP
      onMessage: _handleMessage,
      onConnected: () => setState(() => _isConnected = true),
      onDisconnected: () => setState(() => _isConnected = false),
    );

    _initialize();
  }

  Future<void> _initialize() async {
    await _ttsService.initialize();
    await _axonClient.connect();
  }

  void _handleMessage(Map<String, dynamic> message) {
    setState(() {
      _messageCount++;
    });

    final messageType = message['type'] as String?;

    if (messageType == 'speak') {
      final text = message['text'] as String? ?? '';
      final priority = message['priority'] as int? ?? 50;
      final context = message['context'] as Map<String, dynamic>?;

      // Update UI
      setState(() {
        _lastMessage = text;
        _currentContext = context?['current_app'] ?? 'Unknown';
      });

      // Try Dead Reckoning first
      final prediction = _deadReckoner.predict(context ?? {});
      
      if (prediction != null && prediction['confidence'] > 0.8) {
        // Use local prediction (faster, no LLM)
        _ttsService.speak(prediction['speech'] as String);
      } else {
        // Use server-provided text (from LLM)
        _ttsService.speak(text);
      }
    }
  }

  @override
  void dispose() {
    _axonClient.disconnect();
    _ttsService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              _buildHeader(),
              const SizedBox(height: 40),

              // Connection Status
              _buildConnectionStatus(),
              const SizedBox(height: 40),

              // Current Context
              _buildContextCard(),
              const SizedBox(height: 24),

              // Last Message
              _buildLastMessage(),
              
              const Spacer(),

              // Stats
              _buildStats(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'AXON',
          style: TextStyle(
            fontSize: 48,
            fontWeight: FontWeight.bold,
            foreground: Paint()
              ..shader = const LinearGradient(
                colors: [Color(0xFF00D9FF), Color(0xFF00FF85)],
              ).createShader(const Rect.fromLTWH(0, 0, 200, 70)),
          ),
        ),
        const Text(
          'Voice Bridge v1.0',
          style: TextStyle(
            fontSize: 16,
            color: Colors.white54,
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }

  Widget _buildConnectionStatus() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isConnected
              ? const Color(0xFF00FF85)
              : const Color(0xFFFF4444),
          width: 2,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: _isConnected
                  ? const Color(0xFF00FF85)
                  : const Color(0xFFFF4444),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            _isConnected ? 'CONNECTED TO PC' : 'DISCONNECTED',
            style: TextStyle(
              color: _isConnected ? Colors.white : Colors.white54,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContextCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF00D9FF).withOpacity(0.2),
            const Color(0xFF00FF85).withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'CURRENT CONTEXT',
            style: TextStyle(
              fontSize: 12,
              color: Colors.white54,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _currentContext,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLastMessage() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'LAST SPOKEN',
          style: TextStyle(
            fontSize: 12,
            color: Colors.white54,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            _lastMessage,
            style: const TextStyle(
              fontSize: 18,
              color: Colors.white,
              height: 1.5,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStats() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _buildStatItem('Messages', _messageCount.toString()),
        _buildStatItem('TTS', _ttsService.isInitialized ? 'Ready' : 'Loading'),
        _buildStatItem('Dead Reck', _deadReckoner.patternCount.toString()),
      ],
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF00D9FF),
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.white54,
          ),
        ),
      ],
    );
  }
}
