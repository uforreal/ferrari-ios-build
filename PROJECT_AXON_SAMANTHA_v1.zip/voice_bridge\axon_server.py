"""
AXON SERVER: RAMEN Transport Layer
===================================
WebSocket server with guaranteed message delivery.
Inspired by Uber's RAMEN (Realtime Asynchronous Messaging Network).
"""

import asyncio
import websockets
import json
import time
from typing import Set, Dict, List
from collections import deque

class AXONServer:
    """
    Push-based WebSocket server with:
    - Guaranteed message delivery
    - Reconnection handling
    - Message queuing
    """
    
    def __init__(self, host="0.0.0.0", port=8765):
        self.host = host
        self.port = port
        self.clients: Set[websockets.WebSocketServerProtocol] = set()
        self.message_queue: Dict[str, deque] = {}  # client_id -> queue
        self.running = False
    
    async def register_client(self, websocket):
        """Register new iPhone client"""
        client_id = id(websocket)
        self.clients.add(websocket)
        
        # Initialize message queue for this client
        if client_id not in self.message_queue:
            self.message_queue[client_id] = deque(maxlen=100)
        
        print(f"[AXON] ✓ Client connected: {websocket.remote_address}")
        
        # Send welcome message
        await self.send_to_client(websocket, {
            "type": "connected",
            "message": "Connected to AXON"
        })
        
        # Flush any queued messages
        await self.flush_queue(websocket)
    
    async def unregister_client(self, websocket):
        """Handle client disconnect"""
        self.clients.discard(websocket)
        print(f"[AXON] ✗ Client disconnected: {websocket.remote_address}")
    
    async def send_to_client(self, websocket, message: Dict):
        """Send message to specific client with delivery guarantee"""
        try:
            await websocket.send(json.dumps(message))
            return True
        except websockets.exceptions.ConnectionClosed:
            # Queue for later delivery
            client_id = id(websocket)
            self.message_queue[client_id].append(message)
            print(f"[AXON] Message queued for offline client")
            return False
    
    async def broadcast(self, message: Dict):
        """Broadcast to all connected clients"""
        print(f"[AXON] Broadcasting to {len(self.clients)} client(s)...")
        
        if not self.clients:
            print("[AXON] ⚠ No clients connected. Message lost.")
            return
        
        disconnected = set()
        sent_count = 0
        for client in self.clients:
            success = await self.send_to_client(client, message)
            if success:
                sent_count += 1
                print(f"[AXON] ✓ Sent to {client.remote_address}")
            else:
                disconnected.add(client)
        
        print(f"[AXON] Broadcast complete: {sent_count}/{len(self.clients)} delivered")
        
        # Clean up disconnected clients
        for client in disconnected:
            await self.unregister_client(client)
    
    async def flush_queue(self, websocket):
        """Send all queued messages to reconnected client"""
        client_id = id(websocket)
        if client_id not in self.message_queue:
            return
        
        queue = self.message_queue[client_id]
        while queue:
            message = queue.popleft()
            await self.send_to_client(websocket, message)
            await asyncio.sleep(0.1)  # Don't overwhelm client
    
    async def handle_client(self, websocket):
        """Handle individual client connection"""
        try:
            await self.register_client(websocket)
            
            async for message in websocket:
                # Handle incoming messages from iPhone
                try:
                    data = json.loads(message)
                    print(f"[AXON] ← Received: {data.get('type', 'unknown')}")
                    
                    if data.get("type") == "ping":
                        await self.send_to_client(websocket, {"type": "pong"})
                
                except json.JSONDecodeError:
                    print(f"[AXON] ⚠ Invalid JSON received")
        
        except Exception as e:
            print(f"[AXON] ⚠ Client handler error: {e}")
        
        finally:
            await self.unregister_client(websocket)
    
    async def start(self):
        """Start the AXON server"""
        self.running = True
        print(f"\n{'='*60}")
        print(f"  AXON Server (RAMEN Transport)")
        print(f"  Listening on ws://{self.host}:{self.port}")
        print(f"{'='*60}\n")
        
        async with websockets.serve(self.handle_client, self.host, self.port):
            await asyncio.Future()  # Run forever
    
    def push_event(self, payload: Dict):
        """
        Thread-safe event push (called from main Optic Nerve thread).
        This is the main entry point for pushing to iPhone.
        """
        asyncio.create_task(self.broadcast(payload))


# Standalone test
if __name__ == "__main__":
    server = AXONServer()
    asyncio.run(server.start())
