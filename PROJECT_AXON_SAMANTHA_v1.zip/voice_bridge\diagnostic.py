"""
DIAGNOSTIC TEST: Isolating the Problem
=======================================
Run this to see exactly what's working and what's broken.
"""

import time
import ctypes
from ctypes import wintypes
import asyncio
import json

print("="*60)
print("  PROJECT AXON: DIAGNOSTIC TEST")
print("="*60)

# ============================================
# TEST 1: Can we detect the active window?
# ============================================
print("\n[TEST 1] Windows API - Active Window Detection")
print("-" * 50)

user32 = ctypes.windll.user32

def get_active_window():
    hwnd = user32.GetForegroundWindow()
    length = user32.GetWindowTextLengthW(hwnd) + 1
    buffer = ctypes.create_unicode_buffer(length)
    user32.GetWindowTextW(hwnd, buffer, length)
    return buffer.value

print("I will check the active window 5 times, 1 second apart.")
print("Switch to a DIFFERENT window during this test!\n")

last_window = ""
for i in range(5):
    current = get_active_window()
    status = "CHANGED!" if current != last_window and last_window != "" else ""
    print(f"  [{i+1}] Active: {current[:50]}... {status}")
    last_window = current
    time.sleep(1)

print("\n✓ TEST 1 PASSED if you saw window titles change when you clicked another window.")

# ============================================
# TEST 2: Can we detect the process name?
# ============================================
print("\n[TEST 2] Process Name Detection (psutil)")
print("-" * 50)

try:
    import psutil
    
    def get_process_name():
        hwnd = user32.GetForegroundWindow()
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        try:
            return psutil.Process(pid.value).name()
        except:
            return "unknown"
    
    print("Current process name:", get_process_name())
    print("✓ TEST 2 PASSED - psutil is working")
except ImportError:
    print("✗ TEST 2 FAILED - psutil not installed. Run: pip install psutil")

# ============================================
# TEST 3: Can we send a WebSocket message?
# ============================================
print("\n[TEST 3] WebSocket Server & Client")
print("-" * 50)

try:
    import websockets
    
    async def test_websocket():
        # Start server
        async def handler(websocket):
            await websocket.send(json.dumps({"type": "test", "text": "Hello from server!"}))
            print("  Server: Sent test message")
        
        try:
            server = await websockets.serve(handler, "localhost", 9999)
            print("  Server: Started on ws://localhost:9999")
            
            # Connect as client
            async with websockets.connect("ws://localhost:9999") as ws:
                print("  Client: Connected to server")
                msg = await ws.recv()
                print(f"  Client: Received: {msg}")
            
            server.close()
            await server.wait_closed()
            print("✓ TEST 3 PASSED - WebSocket works")
        except Exception as e:
            print(f"✗ TEST 3 FAILED - {e}")
    
    asyncio.run(test_websocket())
except ImportError:
    print("✗ TEST 3 FAILED - websockets not installed")

# ============================================
# TEST 4: Can we make the PC speak?
# ============================================
print("\n[TEST 4] Text-to-Speech (SAPI)")
print("-" * 50)

try:
    import win32com.client
    speaker = win32com.client.Dispatch("SAPI.SpVoice")
    print("  Speaking: 'Test one two three'...")
    speaker.Speak("Test one two three", 1)  # Async
    time.sleep(2)
    print("✓ TEST 4 PASSED if you heard the voice")
except ImportError:
    print("✗ TEST 4 FAILED - pywin32 not installed. Run: pip install pywin32")
except Exception as e:
    print(f"✗ TEST 4 FAILED - {e}")

# ============================================
# TEST 5: Real-time focus change detection
# ============================================
print("\n[TEST 5] Real-time Focus Change Loop")
print("-" * 50)
print("I will watch for 10 seconds. Switch windows during this time!")
print("You should see a message EVERY time you switch.\n")

last_process = ""
start_time = time.time()
changes_detected = 0

while time.time() - start_time < 10:
    current_process = get_process_name() if 'get_process_name' in dir() else get_active_window()[:20]
    
    if current_process != last_process:
        if last_process != "":
            changes_detected += 1
            print(f"  🔄 CHANGE #{changes_detected}: {last_process} -> {current_process}")
        last_process = current_process
    
    time.sleep(0.1)  # 100ms

print(f"\nTotal changes detected: {changes_detected}")
if changes_detected >= 2:
    print("✓ TEST 5 PASSED - Focus detection is working!")
else:
    print("⚠ TEST 5 INCONCLUSIVE - Try switching windows more during the test")

# ============================================
# SUMMARY
# ============================================
print("\n" + "="*60)
print("  DIAGNOSTIC COMPLETE")
print("="*60)
print("""
If all tests passed, the issue is likely in:
- The integration between components
- The async/threading code in run_system.py

If TEST 1/2 failed: Windows API issue
If TEST 3 failed: WebSocket issue  
If TEST 4 failed: TTS issue
If TEST 5 failed: Focus detection timing issue
""")
