"""
RESONANCE ENGINE: The Vibe Synthesizer
======================================
Translates raw behavior signals into social reflexes.
- Inputs: Presence (User Active?), Velocity (Actions/min), Repetition (Undo/Redo).
- Logic: Consults 'vibe_map.json'.
- Output: Text to speak (or None).
"""

import json
import time
import random
import os

class ResonanceEngine:
    def __init__(self, vibe_map_path="vibe_map.json"):
        self.vibe_map_path = vibe_map_path
        self.rules = self._load_rules()
        
        # State Tracking
        self.last_action_time = time.time()
        self.action_history = []  # List of timestamps
        self.undo_history = []    # List of timestamps for Undos
        self.start_time = time.time()
        
        # Current Vibe
        self.current_vibe = "GREETING" # Start with greeting intent
        self.last_speech_time = 0
        self.speech_cooldown = 60 # Seconds between unsolicited remarks
        
    def _load_rules(self):
        try:
            with open(self.vibe_map_path, 'r') as f:
                data = json.load(f)
                print(f"[Resonance] Loaded Vibe Map v{data.get('version', '?')}")
                return data.get('vibe_rules', [])
        except Exception as e:
            print(f"[Resonance] Error loading map: {e}")
            return []

    def _calculate_velocity(self):
        """Actions per minute over the last 60 seconds."""
        now = time.time()
        # Clean old history
        self.action_history = [t for t in self.action_history if now - t < 60]
        return len(self.action_history)

    def _calculate_repetition(self):
        """Undos per minute over the last 60 seconds."""
        now = time.time()
        self.undo_history = [t for t in self.undo_history if now - t < 60]
        return len(self.undo_history)

    def _get_presence_duration(self):
        """How long since the last interaction?"""
        return time.time() - self.last_action_time

    def process_signal(self, trigger=None):
        """
        Main Engine Loop.
        trigger: Specific event like "SAVE_TRIGGERED" or "UNDO_TRIGGERED"
        """
        now = time.time()
        
        # 1. Update Signals
        if trigger:
            self.last_action_time = now
            self.action_history.append(now)
            if trigger == "UNDO_TRIGGERED":
                self.undo_history.append(now)
        
        velocity = self._calculate_velocity()
        repetition = self._calculate_repetition()
        idle_time = self._get_presence_duration()
        
        # 2. Evaluate Rules
        # We look for a matching rule with the highest priority
        selected_rule = None
        
        for rule in self.rules:
            cond = rule["conditions"]
            match = True
            
            # Check Trigger (Instant match)
            if "trigger" in cond:
                if cond["trigger"] != trigger:
                    match = False
            
            # Check Duration (Idle time)
            if "duration_sec" in cond:
                 # Logic: Triggers if we have been idle for ALMOST exactly this time (within a small window)
                 # This prevents it from firing constantly after 30s.
                 # It fires ONCE when crossing the threshold.
                 target = cond["duration_sec"]
                 if not (target - 1 <= idle_time <= target + 1):
                     match = False
            
            # Check Velocity (Abstract High/Low)
            if "velocity" in cond and cond["velocity"] != "ANY":
                if cond["velocity"] == "ZERO" and velocity > 0: match = False
                if cond["velocity"] == "HIGH" and velocity < 20: match = False # Arbitrary threshold
            
            # Check Presence
            if "presence" in cond:
                req_presence = cond["presence"]
                if req_presence == "NEW":
                    # Only matches if system just started (first 5 seconds)
                    if (now - self.start_time) > 5: match = False
                elif req_presence == "HIGH":
                    # Matches if user has been active recently (last 60s)
                    if idle_time > 60: match = False
            
            # Check Repetition
            if "repetition" in cond and cond["repetition"] != "ANY":
                if cond["repetition"] == "HIGH" and repetition < 3: match = False
                if cond["repetition"] == "LOW" and repetition > 0: match = False

            if match:
                # Priority Check
                if selected_rule is None or rule.get("priority", 0) > selected_rule.get("priority", 0):
                    selected_rule = rule
        
        # 3. Determine Output
        if selected_rule:
            vibe_name = selected_rule["vibe_name"]
            
            # Cooldown Logic (Unless it's a specific trigger like Save)
            is_triggered = "trigger" in selected_rule["conditions"]
            if not is_triggered and (now - self.last_speech_time < self.speech_cooldown):
                return None
            
            self.last_speech_time = now
            pool = selected_rule.get("mood_pool", [])
            
            if pool:
                phrase = random.choice(pool)
                print(f"[Resonance] Vibe Detected: {vibe_name} -> '{phrase}'")
                return phrase
            else:
                # Silence vibe
                return None
                
        return None

if __name__ == "__main__":
    # Test Bench
    engine = ResonanceEngine()
    
    print("--- Testing Greeting ---")
    # Simulate fresh start logic (would be handled by initial call)
    print(engine.rules[0]["mood_pool"][0]) 
    
    print("\n--- Testing Trigger (Save) ---")
    print(engine.process_signal(trigger="SAVE_TRIGGERED"))
    
    print("\n--- Testing Silence (Wait 30s...) ---")
    # Simulate waiting
    engine.last_action_time = time.time() - 30
    print(engine.process_signal(trigger=None))
