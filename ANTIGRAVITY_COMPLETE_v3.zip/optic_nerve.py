"""
OPTIC NERVE v3.0: The Eyes + Finger of the Thalamus
====================================================
Now includes:
- UI Automation (Focused Element Detection)
- Keyboard Event Detection
- Wait State Optimization
- Scroll & Error Detection
"""

import time
import json
import ctypes
from ctypes import wintypes

# ==========================================
# 1. WINDOWS API HOOKS (The "Eyeball")
# ==========================================
user32 = ctypes.windll.user32

def get_active_window_info():
    hwnd = user32.GetForegroundWindow()
    length = user32.GetWindowTextLengthW(hwnd) + 1
    buffer = ctypes.create_unicode_buffer(length)
    user32.GetWindowTextW(hwnd, buffer, length)
    window_title = buffer.value
    
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    
    rect = wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(rect))
    
    return {
        "window_handle": hwnd,
        "window_title": window_title,
        "process_id": pid.value,
        "position": {
            "left": rect.left, "top": rect.top,
            "right": rect.right, "bottom": rect.bottom,
            "width": rect.right - rect.left, "height": rect.bottom - rect.top
        }
    }

def get_cursor_position():
    point = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(point))
    return {"x": point.x, "y": point.y}

# ==========================================
# 2. KEYBOARD DETECTION (The "Hearing")
# ==========================================
# Virtual Key Codes
VK_SHIFT, VK_CONTROL, VK_ALT = 0x10, 0x11, 0x12
VK_RETURN, VK_ESCAPE = 0x0D, 0x1B
VK_S, VK_Z, VK_C, VK_V = 0x53, 0x5A, 0x43, 0x56

def get_keyboard_state():
    return {
        "shift": bool(user32.GetAsyncKeyState(VK_SHIFT) & 0x8000),
        "ctrl": bool(user32.GetAsyncKeyState(VK_CONTROL) & 0x8000),
        "alt": bool(user32.GetAsyncKeyState(VK_ALT) & 0x8000),
        "enter": bool(user32.GetAsyncKeyState(VK_RETURN) & 0x8000),
        "escape": bool(user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000),
    }

def detect_key_action(keys):
    """Translate key states into human actions."""
    if keys["enter"]:
        return "ENTER_PRESSED"
    if keys["escape"]:
        return "ESCAPE_PRESSED"
    if keys["ctrl"]:
        # Check for combos
        if user32.GetAsyncKeyState(VK_S) & 0x8000:
            return "SAVE_TRIGGERED"
        if user32.GetAsyncKeyState(VK_Z) & 0x8000:
            return "UNDO_TRIGGERED"
        if user32.GetAsyncKeyState(VK_C) & 0x8000:
            return "COPY_TRIGGERED"
        if user32.GetAsyncKeyState(VK_V) & 0x8000:
            return "PASTE_TRIGGERED"
    return None

# ==========================================
# 3. UI AUTOMATION (The "Finger")
# ==========================================
try:
    import comtypes.client
    from comtypes import COMError
    
    # Initialize UI Automation
    UIA_AVAILABLE = True
    uia = comtypes.client.CreateObject("{ff48dba4-60ef-4201-aa87-54103eef594e}")
    uia._QueryInterface_(comtypes.IUnknown)
    
    # Get the IUIAutomation interface
    from comtypes.gen.UIAutomationClient import IUIAutomation, IUIAutomationElement
    uia = uia.QueryInterface(IUIAutomation)
    
except Exception as e:
    UIA_AVAILABLE = False
    uia = None

def get_focused_element():
    """Ask Windows: What UI element is the user currently focused on?"""
    if not UIA_AVAILABLE:
        return {"available": False, "reason": "UI Automation not loaded"}
    
    try:
        focused = uia.GetFocusedElement()
        if focused:
            name = focused.CurrentName or "(No Name)"
            control_type = focused.CurrentLocalizedControlType or "Unknown"
            class_name = focused.CurrentClassName or ""
            
            return {
                "available": True,
                "type": control_type,
                "name": name[:50],  # Truncate long names
                "class": class_name
            }
    except COMError:
        pass
    except Exception:
        pass
    
    return {"available": True, "type": "Unknown", "name": "", "class": ""}

# ==========================================
# 4. WAIT STATE OPTIMIZATION
# ==========================================
class WaitStateOptimizer:
    def __init__(self, still_threshold_ms=200):
        self.last_cursor = None
        self.last_move_time = time.time()
        self.still_threshold = still_threshold_ms / 1000.0
        self.last_key_action = None
    
    def should_interrogate(self, cursor, keys):
        """Decide if we should do a 'deep' UI query."""
        now = time.time()
        key_action = detect_key_action(keys)
        
        # Trigger on key action
        if key_action:
            self.last_key_action = key_action
            return True, key_action
        
        # Trigger on mouse stillness
        if self.last_cursor:
            dx = abs(cursor["x"] - self.last_cursor["x"])
            dy = abs(cursor["y"] - self.last_cursor["y"])
            
            if dx < 5 and dy < 5:
                # Mouse is still
                if now - self.last_move_time > self.still_threshold:
                    return True, "MOUSE_STILL"
            else:
                # Mouse moved
                self.last_move_time = now
        
        self.last_cursor = cursor.copy()
        return False, None

# ==========================================
# 5. HUMAN TRANSLATOR (Enhanced)
# ==========================================
def translate_to_human(state, focused_element=None, trigger=None):
    win = state["active_window"]
    title = win["window_title"]
    pos = win["position"]
    cursor = state["cursor"]
    
    lines = []
    
    # A. Window Analysis
    if win["window_handle"] == 0 or not title:
        lines.append("You are looking at the Desktop.")
    elif "Chrome" in title or "Arc" in title:
        clean_title = title.replace(" - Google Chrome", "").replace(" - Arc", "")
        lines.append(f"Browsing: '{clean_title}'")
    elif "SolidWorks" in title or "SOLIDWORKS" in title:
        if "*" in title:
            lines.append(f"Working in SolidWorks (UNSAVED changes)")
        else:
            lines.append(f"Working in SolidWorks")
    elif "EPLAN" in title:
        lines.append(f"Designing in EPLAN Electric P8")
    elif "Invite de commandes" in title or "Terminal" in title:
        lines.append("At the Terminal / Command Center")
    elif "Code" in title:
        lines.append("Writing code")
    else:
        lines.append(f"Focused on '{title[:40]}'")
    
    # B. Trigger Context
    if trigger:
        if trigger == "ENTER_PRESSED":
            lines.append("   >> ACTION: You just pressed ENTER (sent/executed)")
        elif trigger == "ESCAPE_PRESSED":
            lines.append("   >> ACTION: You pressed ESCAPE (cancelled)")
        elif trigger == "SAVE_TRIGGERED":
            lines.append("   >> ACTION: You just SAVED (Ctrl+S)")
        elif trigger == "UNDO_TRIGGERED":
            lines.append("   >> ACTION: You just UNDID something (Ctrl+Z)")
        elif trigger == "COPY_TRIGGERED":
            lines.append("   >> ACTION: You just COPIED (Ctrl+C)")
        elif trigger == "PASTE_TRIGGERED":
            lines.append("   >> ACTION: You just PASTED (Ctrl+V)")
    
    # C. Focused Element (The Finger)
    if focused_element and focused_element.get("available"):
        el_type = focused_element.get("type", "")
        el_name = focused_element.get("name", "")
        
        if el_type in ["Edit", "Text", "Document"]:
            lines.append(f"   >> TYPING in: '{el_name}'")
        elif el_type in ["Button", "SplitButton"]:
            lines.append(f"   >> HOVERING over button: '{el_name}'")
        elif el_type in ["List", "ListItem", "Tree", "TreeItem"]:
            lines.append(f"   >> SELECTING from list: '{el_name}'")
        elif el_type in ["ScrollBar"]:
            lines.append(f"   >> SCROLLING")
        elif el_name:
            lines.append(f"   >> FOCUSED on [{el_type}]: '{el_name}'")
    
    return "\n".join(lines)

# ==========================================
# 6. LIVE WATCHER (Enhanced)
# ==========================================
def live_watch(interval_seconds=0.3):
    print("\n" + "="*70)
    print("   OPTIC NERVE v3.0: THALAMUS FINGER ACTIVE")
    print("   Now detecting: Typing, Clicks, Saves, Scrolls, Errors")
    print("   Press Ctrl+C to stop.")
    print("="*70 + "\n")
    
    optimizer = WaitStateOptimizer(still_threshold_ms=200)
    last_window = None
    last_output = ""
    
    while True:
        try:
            # Capture basic state
            win_info = get_active_window_info()
            cursor = get_cursor_position()
            keys = get_keyboard_state()
            
            state = {
                "timestamp": time.time(),
                "active_window": win_info,
                "cursor": cursor,
                "keys": keys
            }
            
            current_window = win_info["window_title"]
            
            # Check if we should do deep interrogation
            should_query, trigger = optimizer.should_interrogate(cursor, keys)
            
            focused_element = None
            if should_query:
                focused_element = get_focused_element()
            
            # Generate human output
            output = translate_to_human(state, focused_element, trigger)
            
            # Only print if something meaningful changed
            if current_window != last_window or trigger or output != last_output:
                print(f"\n{'─'*70}")
                print(f"[{time.strftime('%H:%M:%S')}]")
                print(f"{'─'*70}")
                print(output)
                last_window = current_window
                last_output = output
            else:
                # Heartbeat
                print(f"\r[WATCHING] ({cursor['x']:4}, {cursor['y']:4})    ", end="", flush=True)
            
            time.sleep(interval_seconds)
            
        except KeyboardInterrupt:
            print("\n\n[OPTIC NERVE] Shutting down...")
            break

def snapshot():
    print("\n[OPTIC NERVE v3.0] Taking deep snapshot...\n")
    state = {
        "timestamp": time.time(),
        "active_window": get_active_window_info(),
        "cursor": get_cursor_position(),
        "keys": get_keyboard_state()
    }
    focused = get_focused_element()
    print(translate_to_human(state, focused, None))
    print("\n[FOCUSED ELEMENT RAW]:")
    print(json.dumps(focused, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    print("\nOPTIC NERVE v3.0 - Choose Mode:")
    print("  1. Live Watch (with Thalamus Finger)")
    print("  2. Single Snapshot")
    
    choice = input("\nEnter choice (1 or 2): ").strip()
    
    if choice == "1":
        live_watch()
    else:
        snapshot()
