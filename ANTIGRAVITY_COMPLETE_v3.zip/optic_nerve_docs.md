# Optic Nerve v3.0: Documentation

## What This Is

The `optic_nerve.py` script is the **"Eyes + Finger"** of the Thalamus system. It captures what is happening on your Windows screen and **interrogates** apps to understand your actions.

---

## Capabilities

| Sensor              | What it Detects                                                   |
| ------------------- | ----------------------------------------------------------------- |
| **Window Title**    | Which app you are using, unsaved changes (\*)                     |
| **Cursor Position** | Where you are pointing                                            |
| **Keyboard Events** | Enter, Escape, Ctrl+S (save), Ctrl+Z (undo), Ctrl+C/V             |
| **Focused Element** | The specific button, text field, or list you are interacting with |
| **Wait State**      | Only asks "deep questions" when you stop moving or click          |

---

## New Features (v3.0)

### 1. Keyboard Event Detection

Detects when you:

- Press **Enter** (sent a message, executed a command)
- Press **Escape** (cancelled an action)
- Press **Ctrl+S** (saved your work)
- Press **Ctrl+Z** (undid something)
- Press **Ctrl+C/V** (copy/paste)

### 2. Focused Element Detection (The "Finger")

Uses Windows UI Automation to ask: _"What is the user currently interacting with?"_

- Detects if you are **typing** in a text field
- Detects if you are **hovering** over a button
- Detects if you are **selecting** from a list or tree
- Detects if you are **scrolling**

### 3. Wait State Optimization

Saves CPU by only doing "deep" interrogation when:

- Mouse has been still for 200ms+
- OR a click/key event is detected

---

## Example Output

```text
──────────────────────────────────────────────────────────────────────
[12:25:01]
──────────────────────────────────────────────────────────────────────
Working in SolidWorks (UNSAVED changes)
   >> SELECTING from list: 'Sketch1'
   >> ACTION: You just SAVED (Ctrl+S)
```

---

## How To Run

```bash
cd C:\Users\HP\Desktop\ANTI-GRAVITY
python optic_nerve.py
```

Choose **Mode 1** for live monitoring.

---

## Dependencies

- `comtypes` (installed via pip)

---

## Future Gaps (Under Review)

| Gap           | Description                                   | Status          |
| ------------- | --------------------------------------------- | --------------- |
| Sound Gap     | Capture audio to understand tutorial context  | 🔍 Under Review |
| Multi-Monitor | Track which screen you're looking at          | 🔍 Under Review |
| Dwell Time    | Detect "thinking" vs "stuck" vs "interrupted" | 🔍 Under Review |
| Clipboard     | Track copy-paste data movement                | 🔍 Under Review |

---

_Updated: 2024-12-31 | Version: 3.0 (Thalamus Finger)_
